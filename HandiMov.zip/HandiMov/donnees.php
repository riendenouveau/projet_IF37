<?php
    @include_once "getDonnees.php";
    echo json_encode(getDonnees());


     