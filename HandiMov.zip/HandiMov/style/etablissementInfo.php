<style>
    #infoEtablissement{
    width : 40%;
}
#carteEtablissement{
    width : 60%;
}

@media screen and (min-width:900px) {
    #carteEtablissement{
        width: 60%;
    }
    #infoEtablissement{
        width: 40%;
    }
}
@media screen and (max-width:899px) {
    #carteEtablissement{
        width: 100%;
    }
    #infoEtablissement{
        width: 100%;
    }
}
</style>