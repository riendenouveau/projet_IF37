<style>
    #infoEtablissement{
    width : 0%;
    display: none;
}

#carteEtablissement{
    width : 100%;
}

@media screen and (min-width:900px) {
    #carteEtablissement{
        width: 100%;
    }
    #infoEtablissement{
        width: 0%;
        display: none;
    }
}
@media screen and (max-width:899px) {
    #carteEtablissement{
        width: 100%;
    }
    #infoEtablissement{
        width: 0%;
        display: none;
    }
}
</style>